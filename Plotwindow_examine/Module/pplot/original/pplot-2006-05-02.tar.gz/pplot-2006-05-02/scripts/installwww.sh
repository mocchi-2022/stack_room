#!/bin/sh
/bin/rm ../www/*.*~
if ! scp ../www/*.* pierphil@pplot.sourceforge.net:/home/groups/p/pp/pplot/htdocs
then
    exit 1
fi
echo "$0: OK"
