#!/bin/sh

if [ -z "$1" ]
then
    echo "$0: argument expected"
    exit 1
fi

if ! cd pplot
then
    exit 1
fi

echo "$0: now making the tag"
if ! cvs tag "$1" .
then
    exit 1
fi
echo "$0: OK"
