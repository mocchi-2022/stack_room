#include "QPPlotDemo.h"

#include <qapplication.h>

#include <string>
using std::string;

int main (int argc, char *argv[]) {

  QApplication theApp (argc, argv);

  QWidget *theDemoWidget = 0;
  if (argc == 1) {
   theDemoWidget = new QPPlotDemo ();
  }
  else {
    string theArg = argv[1];
    if (theArg == "-ruby" || theArg == "-script") {
     theDemoWidget = new QPPlotRubyDemo ();
    }
    else if (theArg == "-demo") {
      int theIndex = 0;
      if (argc==3) {
	char *theArg2 = argv[2];
	sscanf (theArg2, "%d", &theIndex);
      }
      theDemoWidget = new QSinglePPlotDemo (theIndex);
      
    }
    else {
     theDemoWidget = new QP3DPlotDemo ();
    }
  }
  theApp.setMainWidget (theDemoWidget);
  theDemoWidget->show ();
  return theApp.exec ();
}
