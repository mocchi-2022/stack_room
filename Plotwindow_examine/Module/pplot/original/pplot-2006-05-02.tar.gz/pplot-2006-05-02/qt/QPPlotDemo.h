/***************************************************************************
                          simple.h  -  pplot qt demo widget
                             -------------------
    begin                : Thu Oct 17 21:59:18 CEST 2002
    copyright            : (C) 2002 by Pier Philipsen
    email                : pier@localhost.localdomain
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef QPPLOTDEMO_H
#define QPPLOTDEMO_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <qwidget.h>

class QTextEdit;
class PPlot;

/** QPPlotDemo is the base class of the project */
class QPPlotDemo : public QWidget
{
  Q_OBJECT 
  public:
    /** construtor */
    QPPlotDemo(QWidget* parent=0, const char *name=0);
    /** destructor */
    ~QPPlotDemo(){};
};

class QSinglePPlotDemo : public QWidget
{
  Q_OBJECT 
  public:
    /** construtor */
    QSinglePPlotDemo(int inIndex, QWidget* parent=0, const char *name=0);
};

class QPPlotRubyDemo : public QWidget
{
  Q_OBJECT 
  public:
    /** construtor */
    QPPlotRubyDemo(QWidget* parent=0, const char *name=0);

  public slots:
    void ApplyScript ();
    void LoadScript ();
    void SetScriptType (int inType) {mScriptType = inType;};
 protected:
  PPlot *mPPlot;
  QTextEdit *mTextEdit;
  int mScriptType;
};

class QP3DPlotDemo : public QWidget
{
  Q_OBJECT 
  public:
    /** construtor */
    QP3DPlotDemo(QWidget* parent=0, const char *name=0);
    /** destructor */
    ~QP3DPlotDemo(){};

 protected:
};

#endif
