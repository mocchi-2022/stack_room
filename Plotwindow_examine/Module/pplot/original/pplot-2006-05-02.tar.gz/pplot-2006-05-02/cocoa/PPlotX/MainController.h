/* MainController */

#import <Cocoa/Cocoa.h>

@interface MainController : NSObject
{
    IBOutlet id pplotView;
    IBOutlet id scriptTextView;
}

-(IBAction)plot:(id)sender;

@end