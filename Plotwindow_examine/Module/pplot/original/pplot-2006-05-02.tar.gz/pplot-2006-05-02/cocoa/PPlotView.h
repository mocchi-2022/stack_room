//
//  PPlotView.h
//  PPlotCocoa
//
//  Created by Drew McCormack on Mon Nov 04 2002.
//  Copyright (c) 2002 Drew McCormack. All rights reserved.
//

#import <AppKit/AppKit.h>
#import "CocoaPainter.h"

class PMouseEvent;

@interface PPlotView : NSView {
    CocoaPainter  *mCocoaPainter;
}

-(CocoaPainter *)cocoaPainter;
-(void)setCocoaPainter:(CocoaPainter *)painter;

-(PPlot *)pplot;

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;

@end


@interface PPlotView (ProtectedMethods)
-(PMouseEvent)convertMouseEvent:(NSEvent *)cocoaEvent;
@end
