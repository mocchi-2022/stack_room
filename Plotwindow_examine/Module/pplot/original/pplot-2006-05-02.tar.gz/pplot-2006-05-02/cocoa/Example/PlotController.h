/* PlotController */

#import <Cocoa/Cocoa.h>

@interface PlotController : NSObject
{
    IBOutlet id pplotView1, pplotView2, pplotView3, pplotView4, pplotView5, pplotView6,
                pplotView7, pplotView8;
}
@end