#import "PlotController.h"
#import <PPlot/PPlotView.h>
#import <PPlot/CocoaPainter.h>

@implementation PlotController

-(void)awakeFromNib {
    MakeExamplePlot (1, [pplotView1 cocoaPainter]->mPPlot); 
    MakeExamplePlot (2, [pplotView2 cocoaPainter]->mPPlot); 
    MakeExamplePlot (3, [pplotView3 cocoaPainter]->mPPlot); 
    MakeExamplePlot (4, [pplotView4 cocoaPainter]->mPPlot); 
    MakeExamplePlot (5, [pplotView5 cocoaPainter]->mPPlot); 
    MakeExamplePlot (6, [pplotView6 cocoaPainter]->mPPlot); 
    MakeExamplePlot (7, [pplotView7 cocoaPainter]->mPPlot); 
    MakeExamplePlot (8, [pplotView8 cocoaPainter]->mPPlot); 
}

@end
