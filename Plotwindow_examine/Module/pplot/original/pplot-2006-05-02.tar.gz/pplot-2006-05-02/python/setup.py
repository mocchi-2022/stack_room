#!/usr/bin/env python
from distutils.core import setup, Extension
import os

os.system("swig -v -c++ -python -shadow pplot.i")

pplotExtMod = Extension("_pplot", 
       ["pplot_wrap.cxx","../generic/PPlot.cpp"], 
       include_dirs=["../generic"],
       libraries=["stdc++"]
       )
setup( name          = "pplot", 
       version       = "0.1.0",
       description   = "Python interface to the pplot plotting library",
       author        = "Pier Philipsen and Drew McCormack",
       author_email  = "drewmccormack@mac.com",
       url           = "http://pplot.sourceforge.net",
       py_modules    = [ "pplot" ],
       ext_modules   = [ pplotExtMod ],
       )


