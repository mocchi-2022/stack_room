# example python script for pplot
import pplot
plot = pplot.GetCurrentPPlot()
plot.mPlotDataContainer.ClearData()
xdata=[-1.0,0.0,1.0,2.0,3.0,4.0]
ydata=[1.0,-2.0,3.0,4.0,5.0,6.0]
plot.mPlotDataContainer.AddXYPlot(xdata,ydata)
