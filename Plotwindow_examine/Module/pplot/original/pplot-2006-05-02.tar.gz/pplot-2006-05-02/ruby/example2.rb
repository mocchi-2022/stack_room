# multiply y data with 2

# example ruby script for pplot
#require 'pplot' # leave this out if you run embedded ruby


plot = Pplot::GetCurrentPPlot()

plotcount = plot.mPlotDataContainer.GetPlotCount ()

if plotcount<1
return
end

xdata = plot.mPlotDataContainer.GetXData (0)
ydata = plot.mPlotDataContainer.GetYData (0)

for i in 0...ydata.size
  ydata[i] = 2*ydata[i]
end

plot.mPlotDataContainer.ClearData ();# remove old data
plot.mPlotDataContainer.AddXYPlot (xdata,ydata)# replace with new
