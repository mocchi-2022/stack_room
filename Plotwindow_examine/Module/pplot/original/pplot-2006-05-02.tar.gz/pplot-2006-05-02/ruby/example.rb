# example ruby script for pplot
#require 'pplot' # leave this out if you run embedded ruby
plot = Pplot::GetCurrentPPlot()
plot.mPlotDataContainer.ClearData ()
xdata=[-1,0,1,2,3,4]
ydata=[1,-2,3,4,5,6]
plot.mPlotDataContainer.AddXYPlot (xdata,ydata)
