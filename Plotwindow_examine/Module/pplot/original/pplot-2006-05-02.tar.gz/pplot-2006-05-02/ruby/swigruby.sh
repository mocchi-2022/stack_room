#!/bin/sh


#hdrdir = $(rubylibdir)/$(arch)

if ! swig -v -c++ -ruby pplot.i
then
echo "swig failed"
exit 1
fi

gcc -fpic -c ../generic/PPlot.cpp pplot_wrap.cxx \
      -I $RUBYINCL -I ../generic

gcc -shared PPlot.o pplot_wrap.o -o pplot.so -lstdc++

