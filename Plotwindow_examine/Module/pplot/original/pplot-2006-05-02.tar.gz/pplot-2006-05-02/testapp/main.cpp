#include "../generic/PPlot.h"

#include <stdio.h>


int main () {


  float theAr[7] = {0.12, 3.5, 7.8, 9.9, 10, 10.1, 14.7};
  for (int theI=0;theI<7;theI++) {
    float theSpan = theAr[theI];
    printf ("val:%f, pref%f\n", theSpan, TickInfo::RoundSpan (theSpan));
  }

  PPlot thePlot;
  DummyPainter thePainter;

  MakeExamplePlot4 (thePlot);

  bool theRes = thePlot.Draw (thePainter);

  float theMin = thePlot.mYAxisSetup.mMin;
  float theMax = thePlot.mYAxisSetup.mMax;
  printf ("data range %f, %f\n", theMin, theMax);

  if (theRes) {
    printf ("ready\n");
  }
  
  return 0;
}
